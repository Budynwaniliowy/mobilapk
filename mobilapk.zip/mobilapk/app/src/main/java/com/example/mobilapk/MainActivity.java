package com.example.mobilapk;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button mainButton;
    private Button enableButton;
    private TextView counterTextView;
    private int clickCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainButton = findViewById(R.id.mainButton);
        enableButton = findViewById(R.id.enableButton);
        counterTextView = findViewById(R.id.counterTextView);

        mainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;

                mainButton.setEnabled(false);

                counterTextView.setText("Click Count: " + clickCount);

                Toast.makeText(MainActivity.this, "Main button is now disabled", Toast.LENGTH_SHORT).show();
            }
        });

        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainButton.setEnabled(true);

                Toast.makeText(MainActivity.this, "Main button is now enabled", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
